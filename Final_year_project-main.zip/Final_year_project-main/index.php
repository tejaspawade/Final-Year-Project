<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="partials/CSS/index.css">
    <title>Login</title>
</head>

<body>
    <!-- <h1>Hello, world!</h1> -->
    <nav class="main-nav">
        <div class="Logo">
            <img src="partials/CSS/Logo-2-4.png" alt="" width="350" height="80">
        </div>
        <div class='menu-link'>
            <ul>
                <li>
                    <div class="dropdown">
                        <a data-toggle="dropdown" href="#">Login</a>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <a class="dropdown-item" href="/hostel/partials/user.php">Faculty</a>
                            <a class="dropdown-item" href="/hostel/partials/_student.php">Student/Parents</a>
                        </div>
                    </div>
                </li>
                <li>
                    <a href="https://google.com">Hostels</a>
                </li>
                <li>
                    <a href="https://google.com">Facilities</a>
                </li>
                <li>
                    <a href="https://google.com">Staff</a>
                </li>
            </ul>
        </div>
    </nav>
    <!-- <div class="container my-4">
        <a class="btn btn-primary" href="user.php" role="button">Faculty</a>
        <a class="btn btn-primary" href="_student.php" role="button">Student/Parents</a>
        <a class="btn btn-primary" href="partials/_management.php" role="button">Management</a>
    </div> -->

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>

</html>